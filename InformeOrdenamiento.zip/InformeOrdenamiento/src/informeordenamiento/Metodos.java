/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package informeordenamiento;
/**
 *
 * @author sebastianvillar
 */
public class Metodos {

    public static void MostrarVector(int []v){
        int largo=v.length;
        for (int i=0;i<largo;i++){
            System.out.print (v[i]+ "  ");           
        }  
        System.out.println();
    }    
    
    //desde < hasta, hasta<v.length, desde >=0;
    public static int ObtenerMayor(int []v,int desde, int hasta){
        int mayor=v[desde];
        for (int i=desde; i<hasta; i++){
            if (v[i]>mayor)
                mayor=v[i];           
        }
        return mayor;
    }
    
    
    //desde < hasta, hasta<v.length, desde >=0;
    public static int ObtenerMenor(int []v,int desde, int hasta){
        int menor=v[desde];
        for (int i=desde; i<hasta; i++){
            if (v[i]< menor)
                menor=v[i];                
        }
        return menor;
    }   

            //desde < hasta, hasta<v.length, desde >=0;
    public static int ObtenerPosMenor(int []v,int desde, int hasta){
        int menor=v[desde];
        int pos=desde;
        for (int i=desde; i<hasta; i++){
            if (v[i]< menor){
                menor=v[i];
                pos=i;
            }   
        }
        return pos;
    } 
    
    //desde < hasta, hasta<v.length, desde >=0;
    public static int ObtenerPosMayor(int []v,int desde, int hasta){
        int mayor=v[desde];
        int pos=desde;
        for (int i=desde; i<=hasta; i++){
            if (v[i]> mayor){
                mayor=v[i];
                pos=i;
            }    
        }
        return pos;
    }     
    
    public static void Ordenar1(int []v){
        int contadorExterno=0;
        int contadorInterno=0;
        int largo=v.length;
        int aux=0;
        for (int i=0;i<largo;i++){       
            for (int j=i+1;j<largo;j++){
                if (v[i]>v[j]){
                    aux=v[i];
                    v[i]=v[j];
                    v[j]=aux;
                }
                contadorInterno++;
            }                                          
            contadorExterno++;  
            System.out.println("Recorrida nº: "+contadorExterno);
            System.out.print("Cantidad de movimientos: "+contadorInterno);
            System.out.println();
            contadorInterno=0;
        }
    }
    
    public static void Ordenar2(int []v){
        int contadorExterno=0;
        int contadorInterno=0;
        int largo=v.length;
        int aux=0;
        for (int i=0;i<largo;i++){            
            for (int j=0;j<largo-1;j++){
                if (v[j]>v[j+1]){
                    aux=v[j];
                    v[j]=v[j+1];
                    v[j+1]=aux;
                } 
                contadorInterno++;                
            }
            contadorExterno++;  
            System.out.println("Recorrida nº: "+contadorExterno);
            System.out.print("Cantidad de movimientos: "+contadorInterno);
            System.out.println();
            contadorInterno=0;
        }
    }
 
    public static void  Ordenar2Mejorado(int []v){
        int contadorExterno=0;
        int contadorInterno=0;
        boolean ordenado=false;
        int largo=v.length;
        int aux=0;
        for (int i=0; i<largo && !ordenado; i++){
            ordenado=true;
            for (int j=0;j<largo-1;j++){
                if (v[j]>v[j+1]){
                    ordenado=false;
                    aux=v[j];
                    v[j]=v[j+1];
                    v[j+1]=aux;
                } 
                contadorInterno++;
            }
            contadorExterno++;  
            System.out.println("Recorrida nº: "+contadorExterno);
            System.out.print("Cantidad de movimientos: "+contadorInterno);
            System.out.println();
            contadorInterno=0;
        }
    }

    //FALTA AJUSTAR ORDENAMIENTO   
    public static void OrdenarMinimo(int []v){
        int largo=v.length;
        int posicionMinimo=0;
        int aux=0;
        int contador=0;
        for (int i=0; i<=largo-1; i++){
           posicionMinimo= ObtenerPosMenor(v,i,largo);
           aux=v[i];
           v[i]=v[posicionMinimo];
           v[posicionMinimo]=aux;
        }
    }
     
     public static void Ordenar3(int []v){
        int largo=v.length;
        int posminimo=0;
        int aux=0;
        int contador=0;
        for (int i=0; i<largo;i++){
            posminimo=ObtenerPosMenor(v,i,largo);
            aux=v[i];
            v[i]=v[posminimo];
            v[posminimo]=aux;
            contador++;             
        }
        System.out.println("Recorrida nº: 1");
        System.out.print("Cantidad de movimientos: "+contador);
        System.out.println();
    }
     
    public static void Ordenar4(int []v){
        int posmaximo=0;
        int aux=0;
        int i=v.length-1;
        int contador=0;        
        while (i>0){
            posmaximo=ObtenerPosMayor(v,0,i);
            aux=v[i];
            v[i]=v[posmaximo];
            v[posmaximo]=aux;
            i--;   
            contador++;                         
        }
        System.out.println("Recorrida nº: 1");
        System.out.print("Cantidad de movimientos: "+contador);
        System.out.println();        
    }       

    public static void Ordenar5(int []v){
        int i=0;
        int j=v.length-1;
        int aux=0;
        int pmin;
        int pmax;
        int contador=0;
        while (i<j){
            pmin=ObtenerPosMenor(v,i,j);
            aux=v[i];
            v[i]=v[pmin];
            v[pmin]=aux;
            pmax=ObtenerPosMayor(v,i,j);            
            aux=v[j];
            v[j]=v[pmax];
            v[pmax]=aux;
            i++;
            j--;
            contador++;
        }
        System.out.println("Recorrida nº: 1");
        System.out.print("Cantidad de movimientos: "+contador);
        System.out.println();          
    }

    public static int Ordenar6(int v[]) {
        int contador=0;
        int i, aux, j;
        for (i = 1; i < v.length; i++) {
            aux = v[i];
            j = i - 1;
            while ( (j >= 0)&&(v[j] > aux)  ) {
                v[j + 1] = v[j];
                j--;
            }
            v[j + 1] = aux;
            contador++;            
        }
        System.out.println("Recorrida nº: 1");
        System.out.print("Cantidad de movimientos: "+contador);
        System.out.println();           
        //mostrarvector(v); 
        return contador;
    }

}

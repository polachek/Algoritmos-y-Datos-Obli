/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package informeordenamiento;
import static informeordenamiento.Metodos.*;

/**
 *
 * @author sebastianvillar
 */
public class InformeOrdenamiento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int []v1={15,3,4,11,22,9};
        int [] v11 = v1.clone();
        int [] v12 = v1.clone();
        int [] v13 = v1.clone();        
        int [] v14 = v1.clone();  
        int [] v15 = v1.clone(); 
        int [] v16 = v1.clone();                
        int [] v17 = v1.clone();                        

        int []v2={1,2,3,4,5,6};    
        int [] v21 = v2.clone();
        int [] v22 = v2.clone();
        int [] v23 = v2.clone();  
        int [] v24 = v2.clone();  
        int [] v25 = v2.clone();
        int [] v26 = v2.clone();        
        int [] v27 = v2.clone();                

        int []v3={6,5,4,3,2,1};    
        int [] v31 = v3.clone();
        int [] v32 = v3.clone();
        int [] v33 = v3.clone();        
        int [] v34 = v3.clone();
        int [] v35 = v3.clone(); 
        int [] v36 = v3.clone();  
        int [] v37 = v3.clone(); 
        
        int []v4={3,3,4,3,1,1};    
        int [] v41 = v4.clone();
        int [] v42 = v4.clone();
        int [] v43 = v4.clone();        
        int [] v44 = v4.clone();
        int [] v45 = v4.clone(); 
        int [] v46 = v4.clone();  
        int [] v47 = v4.clone();         
        
        System.out.println("********************************************");
        System.out.println("********************************************");                
        System.out.println("********************************************");
        System.out.println ("           MÉTODO ORDENAR1                 ");
        System.out.println("********************************************");        
        System.out.println("********************************************");
        System.out.println("********************************************");                
        System.out.println();        
        System.out.println("VECTOR 1:");
        MostrarVector(v11);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        Ordenar1(v11);  
        System.out.println(); 
        System.out.println("VECTOR ORDENADO:");                                
        MostrarVector(v11);
                
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 2:");
        MostrarVector(v21);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar1(v21); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v21);        
                
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 3:");
        MostrarVector(v31);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar1(v31); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v31);        
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 4:");
        MostrarVector(v41);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar1(v41); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v41);  
        
        System.out.println();  
        System.out.println();  
        
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println("********************************************");
        System.out.println ("           MÉTODO ORDENAR2                 ");
        System.out.println("********************************************");
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println();        
        System.out.println("VECTOR 1:");
        MostrarVector(v12);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        Ordenar2(v12);  
        System.out.println(); 
        System.out.println("VECTOR ORDENADO:");                                
        MostrarVector(v12);
                
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 2:");
        MostrarVector(v22);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar2(v22); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v22);        
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 3:");
        MostrarVector(v32);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar2(v32); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v32);  
        
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 4:");
        MostrarVector(v42);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar2(v42); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v42);                  

        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println("********************************************");
        System.out.println ("      MÉTODO ORDENAR2 MEJORADO             ");
        System.out.println("********************************************");
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println();        
        System.out.println("VECTOR 1:");
        MostrarVector(v13);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        Ordenar2Mejorado(v13);  
        System.out.println(); 
        System.out.println("VECTOR ORDENADO:");                                
        MostrarVector(v13);
                
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 2:");
        MostrarVector(v23);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar2Mejorado(v23); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v23);        
                              

        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 3:");
        MostrarVector(v33);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar2Mejorado(v33); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v33);          

        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 4:");
        MostrarVector(v43);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar2Mejorado(v43); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v43);               
        
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println("********************************************");
        System.out.println ("      MÉTODO ORDENAR3 - ORDENAR MENOR      ");
        System.out.println("********************************************");
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println();        
        System.out.println("VECTOR 1:");
        MostrarVector(v14);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        Ordenar3(v14);  
        System.out.println(); 
        System.out.println("VECTOR ORDENADO:");                                
        MostrarVector(v14);
                
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 2:");
        MostrarVector(v24);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar3(v24); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v24);        
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 3:");
        MostrarVector(v34);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar3(v34); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v34);           
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 4:");
        MostrarVector(v44);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar3(v44); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v44);                    
        
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println("********************************************");
        System.out.println ("      MÉTODO ORDENAR4 - ORDENAR MAYOR      ");
        System.out.println("********************************************");
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println();        
        System.out.println("VECTOR 1:");
        MostrarVector(v15);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        Ordenar4(v15);  
        System.out.println(); 
        System.out.println("VECTOR ORDENADO:");                                
        MostrarVector(v15);
                
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 2:");
        MostrarVector(v25);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar4(v25); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v25);        
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 3:");
        MostrarVector(v35);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar4(v35); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v35);          
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 4:");
        MostrarVector(v45);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar4(v45); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v45);          
        
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println("********************************************");
        System.out.println (" MÉTODO ORDENAR5 - ORDENAR MENOR Y MAYOR   ");
        System.out.println("********************************************");
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println();        
        System.out.println("VECTOR 1:");
        MostrarVector(v16);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        Ordenar5(v16);  
        System.out.println(); 
        System.out.println("VECTOR ORDENADO:");                                
        MostrarVector(v16);       
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 2:");
        MostrarVector(v26);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar5(v26); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v26);        
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 3:");
        MostrarVector(v36);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar5(v36); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v36);          
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 4:");
        MostrarVector(v46);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar4(v46); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v46);          
        
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println("********************************************");
        System.out.println (" MÉTODO ORDENAR6 - ORDENAR POR INSERCIÓN   ");
        System.out.println("********************************************");
        System.out.println("********************************************");
        System.out.println("********************************************");        
        System.out.println();        
        System.out.println("VECTOR 1:");
        MostrarVector(v17);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        Ordenar6(v17);  
        System.out.println(); 
        System.out.println("VECTOR ORDENADO:");                                
        MostrarVector(v17);
        
        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 2:");
        MostrarVector(v27);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar6(v27); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v27);                

        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 3:");
        MostrarVector(v37);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar6(v37); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v37);              

        System.out.println("-------------------------------------------");  
        System.out.println();        
        System.out.println("VECTOR 4:");
        MostrarVector(v47);        
        System.out.println();
        System.out.println("DETALLE DE MOVIMIENTOS Y RECORRIDAS:");                
        System.out.println();        
        Ordenar4(v47); 
        System.out.println();  
        
        System.out.println("VECTOR ORDENADO:");                        
        MostrarVector(v47);          


        //Inserción
        //Ordenar6(v1);        

    }
    
}
